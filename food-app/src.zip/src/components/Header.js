import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./header.css";

const Header = ({ searchTerm, onSearch }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem("token")); // State for login status

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false); // Update state
  };

  useEffect(() => {
    setIsLoggedIn(!!localStorage.getItem("token")); // Sync state with localStorage
  }, []);

  return (
    <header className="header">
      <div className="logo-container">
        <Link to="/" className="logo-link">
          <img
            src="/images/oshawott.png"
            alt="OSHAWOTT Logo"
            className="logo"
          />
        </Link>
      </div>

      <input
        type="text"
        placeholder="Search"
        className="search-bar"
        onChange={onSearch}
        value={searchTerm}
      />

      <select className="location-text">
        <option value="none" selected disabled hidden>
          Select your Location
        </option>
        <option>Bengaluru</option>
        <option>Delhi</option>
      </select>

      <div className="auth-buttons">
        {!isLoggedIn ? (
          <>
            <Link to="/login" className="auth-link">
              <button className="auth-btn">Login</button>
            </Link>
            <Link to="/register" className="auth-link">
              <button className="auth-btn">Register</button>
            </Link>
          </>
        ) : (
          <button className="auth-btn" onClick={handleLogout}>
            Logout
          </button>
        )}
      </div>

      <div className="cart-container">
        <Link to="/cart" className="cart-link">
          <img src="/images/cart.png" alt="Cart" className="cart-icon" />
        </Link>
      </div>
    </header>
  );
};

export default Header;
