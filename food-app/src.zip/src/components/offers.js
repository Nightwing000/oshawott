import React from "react";
import "./offers.css";

const Offers = () => {
  const offers = [
    { text: "20% OFF", bgColor: "orange", image: "/images/20perc.jpg" },
    { text: "50% OFF", bgColor: "purple", image: "/images/50perc.jpg" },
    { text: "25% OFF", bgColor: "green", image: "/images/25perc.jpg" },
  ];

  return (
    <section>
      <h2 className="section-title">Offers</h2>
      <div className="offers">
        {offers.map((offer, index) => (
          <div
            key={index}
            className="offer-card"
            style={{ backgroundColor: offer.bgColor }}
          >
            <img src={offer.image} alt={`${offer.text} Offer`} className="offer-image" />
            <p className="offer-text">{offer.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Offers;
