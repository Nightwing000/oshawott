import React, { useEffect, useState } from "react";
import "./checkout.css";

const CheckoutPage = ({ cart, setCart }) => {
  const [addresses, setAddresses] = useState([]);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [newAddress, setNewAddress] = useState({ label: "", address: "" });
  const [isUpdating, setIsUpdating] = useState(false);
  const userId = "user123"; // Replace with actual user ID

  const totalCost = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  const deliveryFee = 50;
  const platformFee = 10;
  const gst = Math.round((totalCost + deliveryFee + platformFee) * 0.18);
  const totalAmount = totalCost + deliveryFee + platformFee + gst;

  useEffect(() => {
    // Fetch addresses from the backend when the component mounts
    const fetchAddresses = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/addresses?userId=${userId}`);
        const data = await response.json();
        setAddresses(data);
      } catch (error) {
        console.error("Error fetching addresses", error);
      }
    };
    fetchAddresses();
  }, [userId]);

  const handleAddAddress = async () => {
    if (newAddress.label && newAddress.address) {
      try {
        const response = await fetch("http://localhost:5000/api/addresses", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify({
            label: newAddress.label,
            address: newAddress.address,
            userId,
          }),
        });

        const data = await response.json();
        setAddresses([...addresses, data.address]);
        setNewAddress({ label: "", address: "" });
      } catch (error) {
        console.error("Error adding address", error);
      }
    }
  };

  const handleUpdateAddress = async () => {
    if (selectedAddress && newAddress.label && newAddress.address) {
      try {
        const response = await fetch(`http://localhost:5000/api/addresses/${selectedAddress._id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify({
            label: newAddress.label,
            address: newAddress.address,
          }),
        });

        const data = await response.json();
        const updatedAddresses = addresses.map(address =>
          address._id === data.address._id ? data.address : address
        );
        setAddresses(updatedAddresses);
        setIsUpdating(false);
        setNewAddress({ label: "", address: "" });
      } catch (error) {
        console.error("Error updating address", error);
      }
    }
  };

  const handleDeleteAddress = async (addressId) => {
    try {
      await fetch(`http://localhost:5000/api/addresses/${addressId}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setAddresses(addresses.filter(address => address._id !== addressId));
    } catch (error) {
      console.error("Error deleting address", error);
    }
  };

  return (
    <div className="container">
      {/* Address Section */}
      <div className="delivery-section">
        <h2>📍 Delivery Address:</h2>
        <div className="address-card">
          {addresses.length === 0 ? (
            <p>No saved addresses. Please add an address.</p>
          ) : (
            addresses.map((address) => (
              <div key={address._id} className="address">
                <div className="address-title">{address.label}</div>
                <p>{address.address}</p>
                <button onClick={() => {
                  setSelectedAddress(address);
                  setNewAddress({ label: address.label, address: address.address });
                  setIsUpdating(true);
                }}>Update</button>
                <button onClick={() => handleDeleteAddress(address._id)}>Delete</button>
              </div>
            ))
          )}
        </div>
        <button className="add-address-btn" onClick={() => setIsUpdating(false)}>+ Add New Address</button>
      </div>

      {/* Update/Add Address */}
      {isUpdating ? (
        <div className="update-address">
          <h3>Update Address</h3>
          <input
            type="text"
            placeholder="Label"
            value={newAddress.label}
            onChange={(e) => setNewAddress({ ...newAddress, label: e.target.value })}
          />
          <textarea
            placeholder="Full Address"
            value={newAddress.address}
            onChange={(e) => setNewAddress({ ...newAddress, address: e.target.value })}
          />
          <button onClick={handleUpdateAddress}>Update Address</button>
        </div>
      ) : (
        <div className="add-address">
          <h3>Add New Address</h3>
          <input
            type="text"
            placeholder="Label"
            value={newAddress.label}
            onChange={(e) => setNewAddress({ ...newAddress, label: e.target.value })}
          />
          <textarea
            placeholder="Full Address"
            value={newAddress.address}
            onChange={(e) => setNewAddress({ ...newAddress, address: e.target.value })}
          />
          <button onClick={handleAddAddress}>Add Address</button>
        </div>
      )}

      {/* Cart Summary Section */}
      <div className="cart-section">
        <h2>Your Cart</h2>
        <div className="cart-items">
          {cart.map((item, index) => (
            <div className="cart-item" key={item.id}>
              <span>{index + 1}.</span>
              <div className="item-details">
                <p>{item.name}</p>
                <p>₹{item.price} x {item.quantity}</p>
              </div>
            </div>
          ))}
        </div>
        <textarea placeholder="Any instructions for the chef?"></textarea>
        <button className="btn coupon-btn">Apply coupon</button>
        <div className="bill-details">
          <p>Items total: <span>₹{totalCost}</span></p>
          <p>Delivery Fee: <span>₹{deliveryFee}</span></p>
          <p>Platform Fee: <span>₹{platformFee}</span></p>
          <p>GST (18%): <span>₹{gst}</span></p>
          <p className="total-amount">Total Amount: <span>₹{totalAmount}</span></p>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
